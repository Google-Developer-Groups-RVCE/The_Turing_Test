# Turing Test GDG SIP

## Round 4 integration

Round 4 — Spot the Hallucination is integrated as a native preset. Admins can seed it from Admin → Rounds using **+ R4**, or seed all four presets with **+ Add All Presets**. The first 3 questions are warm-up (0 points); Q4 onward are +10 for correct answers and 0 for wrong answers. The physics question uses the supplied AI-solution image. When the admin evaluates a question, participants receive the correct option and explanation. The implementation uses the existing dev frontend/backend/socket architecture and styling rather than the standalone Round 4 HTML UI.

## Round 4 fixes
- Round 4 only: Q1–Q3 are warm-up questions and award 0 points.
- Round 4 Q4 onward award 10 points for correct answers and 0 for wrong/unanswered.
- Round 4 MCQ answer validation resolves A/B/C/D/E keys against the stored correct option text.
- Round 4 participant UI shows “WARM UP QUESTION” for the first three questions and “Spot the hallucination in Gemini's response” before each actual question.
- Round 4 question 10 remains removed; the supplied research question is retained as `r4-q11` with display order 10.
