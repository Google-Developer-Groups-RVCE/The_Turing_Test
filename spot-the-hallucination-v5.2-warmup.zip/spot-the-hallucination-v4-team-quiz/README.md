# Spot the Hallucination — V5 Team Quiz

- Mobile-friendly Student and Admin/Judge websites.
- Every remaining question is worth **+10 points**; wrong answers are **0**.
- Old Q10 physics duplicate removed.
- Warm-up sequence: Mars, Coffee/IQ, Physics.
- Physics is 4-option and uses the supplied AI-solution image.
- Correct options use explicit indices, fixing the `@` bug.
- Reveal shows correct letter + complete option + explanation.
- Correct submissions automatically add +10 to the team's score.
- Admin can edit team scores.
- Standalone demo score storage uses browser localStorage; true cross-device realtime synchronization will require the later backend integration.


V5.1 fix: leaderboard initialization is now executed before application state initialization, preventing the blank-page startup error.


V5.2: First three questions are warm-up questions and award no points. Questions 4 onward award +10 for correct answers; wrong answers remain 0.
