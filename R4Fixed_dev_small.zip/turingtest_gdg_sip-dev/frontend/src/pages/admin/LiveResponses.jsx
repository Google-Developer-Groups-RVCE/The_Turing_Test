import React, { useState, useEffect, useCallback } from 'react';
import { useSocket } from '../../hooks/useSocket';
import { SOCKET_EVENTS } from '../../utils/constants';
import { getRounds } from '../../api/roundApi';
import { getResponses, exportResponses, deleteResponses } from '../../api/responseApi';
import { Activity, Download, RefreshCw, CheckCircle, XCircle, Search, Filter, Trash2 } from 'lucide-react';

export default function LiveResponses() {
  const socket = useSocket();
  const [rounds, setRounds] = useState([]);
  const [selectedRound, setSelectedRound] = useState('');
  const [responses, setResponses] = useState([]);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState('');
  const [filterCorrect, setFilterCorrect] = useState('');
  const [liveCount, setLiveCount] = useState(0);
  const [selectedUsers, setSelectedUsers] = useState(new Set());

  useEffect(() => {
    getRounds().then(res => {
      const r = res.data.rounds || [];
      setRounds(r);
      const active = r.find(x => x.status === 'active');
      if (active) setSelectedRound(active.id);
      else if (r.length) setSelectedRound(r[0].id);
    });
  }, []);

  const fetchResponses = useCallback(async () => {
    if (!selectedRound) return;
    setLoading(true);
    try {
      const res = await getResponses(selectedRound, { search, correct: filterCorrect });
      const list = res.data?.responses || (Array.isArray(res.data) ? res.data : []);
      setResponses(list);
      setLiveCount(res.data?.total || list.length);
      setSelectedUsers(new Set());
    } catch { /* silent */ }
    finally { setLoading(false); }
  }, [selectedRound, search, filterCorrect]);

  useEffect(() => { fetchResponses(); }, [fetchResponses]);

  // Live response streaming
  useEffect(() => {
    if (!socket) return;
    const handleNewResponse = (data) => {
      if (data.roundId === selectedRound) {
        setResponses(prev => {
          const exists = prev.find(r => r.username === data.username && r.roundId === data.roundId);
          if (exists) return prev;
          return [{ ...data, submittedAt: data.submittedAt || new Date().toISOString() }, ...prev];
        });
        setLiveCount(c => c + 1);
      }
    };
    const handleDeleted = (data) => {
      if (data.roundId === selectedRound) {
        setResponses(prev => prev.filter(r => !data.usernames.includes(r.username)));
        setLiveCount(c => Math.max(0, c - data.usernames.length));
        setSelectedUsers(prev => {
          const next = new Set(prev);
          data.usernames.forEach(u => next.delete(u));
          return next;
        });
      }
    };
    socket.on(SOCKET_EVENTS.RESPONSE_RECEIVED, handleNewResponse);
    socket.on('responses:deleted', handleDeleted);
    return () => {
      socket.off(SOCKET_EVENTS.RESPONSE_RECEIVED, handleNewResponse);
      socket.off('responses:deleted', handleDeleted);
    };
  }, [socket, selectedRound]);

  const handleExport = async () => {
    if (!selectedRound) return;
    try {
      const res = await exportResponses(selectedRound);
      const url = URL.createObjectURL(new Blob([res.data]));
      const a = document.createElement('a');
      a.href = url; a.download = `responses_${selectedRound}.csv`; a.click();
      URL.revokeObjectURL(url);
    } catch { /* silent */ }
  };

  const handleBulkDelete = async () => {
    if (!selectedRound || selectedUsers.size === 0) return;
    if (!window.confirm(`Are you sure you want to delete ${selectedUsers.size} response(s)?`)) return;
    try {
      await deleteResponses(selectedRound, Array.from(selectedUsers));
    } catch (err) {
      alert('Failed to delete responses');
    }
  };

  const toggleSelectAll = (e) => {
    if (e.target.checked) {
      setSelectedUsers(new Set(responses.map(r => r.username)));
    } else {
      setSelectedUsers(new Set());
    }
  };

  const toggleSelectUser = (username) => {
    setSelectedUsers(prev => {
      const next = new Set(prev);
      if (next.has(username)) next.delete(username);
      else next.add(username);
      return next;
    });
  };

  const correctCount = responses.filter(r => r.isCorrect).length;
  const incorrectCount = responses.filter(r => !r.isCorrect).length;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-2xl font-bold text-white flex items-center space-x-2">
          <Activity size={24} className="text-primary-400" />
          <span>Live Responses</span>
          <span className="text-sm font-normal text-slate-500">({liveCount} total)</span>
        </h1>
        <div className="flex gap-2">
          {selectedUsers.size > 0 && (
            <button onClick={handleBulkDelete} className="flex items-center space-x-2 px-3 py-2 rounded-lg border border-rose-500/30 bg-rose-500/10 text-rose-400 hover:bg-rose-500/20 transition-colors text-sm font-semibold">
              <Trash2 size={16} /><span>Delete ({selectedUsers.size})</span>
            </button>
          )}
          <button onClick={handleExport} className="flex items-center space-x-2 px-3 py-2 rounded-lg border border-dark-600 text-slate-300 hover:text-white transition-colors text-sm">
            <Download size={16} /><span>Export CSV</span>
          </button>
          <button onClick={fetchResponses} className="p-2 rounded-lg border border-dark-600 text-slate-400 hover:text-white transition-colors">
            <RefreshCw size={16} />
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        <div className="card text-center py-3">
          <div className="text-2xl font-bold text-white font-mono">{liveCount}</div>
          <div className="text-xs text-slate-500">Total Submissions</div>
        </div>
        <div className="card text-center py-3">
          <div className="text-2xl font-bold text-primary-400 font-mono">{correctCount}</div>
          <div className="text-xs text-slate-500">Correct</div>
        </div>
        <div className="card text-center py-3">
          <div className="text-2xl font-bold text-rose-400 font-mono">{incorrectCount}</div>
          <div className="text-xs text-slate-500">Incorrect</div>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3">
        <select className="input-field py-2 text-sm w-56" value={selectedRound} onChange={e => setSelectedRound(e.target.value)}>
          <option value="all">🌐 All Rounds (Complete Event)</option>
          {rounds.map(r => (
            <option key={r.id} value={r.id}>{r.name} ({r.status})</option>
          ))}
        </select>
        <div className="relative flex-1 min-w-40">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <input className="input-field pl-9 py-2 text-sm" placeholder="Search by username..." value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <select className="input-field py-2 text-sm w-36" value={filterCorrect} onChange={e => setFilterCorrect(e.target.value)}>
          <option value="">All Answers</option>
          <option value="true">Correct Only</option>
          <option value="false">Incorrect Only</option>
        </select>
      </div>

      {/* Table */}
      <div className="card overflow-hidden p-0">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-dark-700 bg-dark-900/50">
                <th className="px-4 py-3 text-left w-10">
                  <input type="checkbox" className="w-4 h-4 rounded border-dark-600 bg-dark-800 checked:bg-primary-500" 
                    checked={responses.length > 0 && selectedUsers.size === responses.length} 
                    onChange={toggleSelectAll} 
                  />
                </th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-400 uppercase tracking-wider">Username</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-400 uppercase tracking-wider">Round / Question</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-400 uppercase tracking-wider">Answer Submitted</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-400 uppercase tracking-wider">Result</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-400 uppercase tracking-wider">Points</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-400 uppercase tracking-wider">Submitted At</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-dark-700/50">
              {loading && <tr><td colSpan={7} className="text-center py-10 text-slate-500">Loading...</td></tr>}
              {!loading && responses.length === 0 && <tr><td colSpan={7} className="text-center py-10 text-slate-500">No responses yet. Waiting for participants...</td></tr>}
              {!loading && responses.map((r, i) => (
                <tr key={`${r.username}-${r.questionId || ''}-${i}`} className="hover:bg-dark-800/40 transition-colors">
                  <td className="px-4 py-3">
                    <input type="checkbox" className="w-4 h-4 rounded border-dark-600 bg-dark-800 checked:bg-primary-500" 
                      checked={selectedUsers.has(r.username)} 
                      onChange={() => toggleSelectUser(r.username)} 
                    />
                  </td>
                  <td className="px-4 py-3 font-mono text-white text-xs font-bold">{r.username}</td>
                  <td className="px-4 py-3 text-xs font-mono text-primary-300">
                    <span className="px-2 py-0.5 rounded bg-dark-800 border border-dark-600">
                      {r.roundId || 'R?'} : {r.questionId || 'Q?'}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-slate-200 max-w-sm font-mono text-xs break-all">
                    {r.answer}
                  </td>
                  <td className="px-4 py-3">
                    {String(r.isCorrect) === 'true' || Number(r.pointsAwarded) > 0
                      ? <span className="flex items-center space-x-1 text-primary-400 font-semibold"><CheckCircle size={14} /><span>Correct</span></span>
                      : <span className="flex items-center space-x-1 text-rose-400 font-semibold"><XCircle size={14} /><span>Incorrect</span></span>}
                  </td>
                  <td className="px-4 py-3 font-mono font-bold text-yellow-400">+{r.pointsAwarded ?? 0} pts</td>
                  <td className="px-4 py-3 text-slate-500 text-xs">
                    {r.submittedAt ? (isNaN(parseInt(r.submittedAt, 10)) ? new Date(r.submittedAt) : new Date(parseInt(r.submittedAt, 10))).toLocaleTimeString() : '—'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
