# Turing Test GDG SIP


## Round 4 integration

Round 4 — Spot the Hallucination is integrated as a native preset. Admins can seed it from Admin → Rounds using **+ R4**, or seed all four presets with **+ Add All Presets**. The Round 4 questions are the latest V5.2 set: first 3 are warm-up (0 points), Q4 onward are +10 for correct answers and 0 for wrong answers. The physics question uses the supplied AI-solution image. When the admin advances/evaluates a question, participants receive the correct option and explanation. The implementation uses the existing dev frontend/backend/socket architecture and styling rather than the standalone Round 4 HTML UI.
